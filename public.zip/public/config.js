/* /config.js  —  DO NOT use `export` here */
window.OPENLEARN_CFG = {
  firebase: {
    apiKey: "AIzaSyBEkph2jnubq_FvZUcHOR2paKoOKhRaULg",
    authDomain: "openlearn-mm.firebaseapp.com",
    databaseURL: "https://openlearn-mm-default-rtdb.firebaseio.com",
    projectId: "openlearn-mm",
    storageBucket: "openlearn-mm.firebasestorage.app",
    messagingSenderId: "977262127138",
    appId: "1:977262127138:web:0ee1d4ac3c45f1334f427b",
    measurementId: "G-E65G177ZNJ",
  },
  paypalClientId:
    "AVpfmQ8DyyatFaAGQ3Jg58XtUt_2cJDr1leqcc_JI8LvKIR2N5WB_yljqCOTTCtvK1hFJ7Q9X0ojXsEC",
  emailjs: {
    publicKey: "WT0GOYrL9HnDKvLUf",
    serviceId: "service_z9tkmvr",
    templateId: "template_q5q471f",
  },
};
